<?php
require_once "config/public_function.php";
include_once "../config.inc.php";
include_once "include/function.php";

$db = Typecho_Db::get();
$prefix=$db->getPrefix();
$options=Typecho_Widget::widget('Widget_Options');
$themeOptions=getThemeOptions();

$cid = isset($_GET['cid']) ? addslashes(trim($_GET['cid'])) : 0;

/*favicon*/
$favicon=$themeOptions["head_favicon"];
/*LOGO*/
$logo=$themeOptions["head_logo_img"];
/*分类导航*/
Typecho_Widget::widget('Widget_Metas_Category_List')->to($category);
$i=0;while($category->next()){
	if($category->parent!=0){continue;}
	$cate[$i]["mid"]=$category->mid;
	$cate[$i]["name"]=$category->name;
	$i++;
}

/*文章内容*/
$query= "SELECT *,c.created as ccreated FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid WHERE c.type='post' AND c.status='publish' AND c.cid=".$cid;
$row = $db->fetchRow($query);
$article=array();
$article["uid"]=$row["uid"];
$article["title"]=$row["title"];
$article["nickname"]=$row["screenName"]!=""?$row["screenName"]:$row["name"];
$article["commentsNum"]=$row["commentsNum"];
$article["viewsNum"]=get_post_view($row["cid"]);
$article["created"]=date("Y-m-d",$row["ccreated"]);
if(strpos($row["text"], '<!--markdown-->')===0){
	$text=substr($row["text"],15);
}
$article["text"]=Markdown::convert($text);
$article["avatar"]=getAuthorAvatar($row["mail"]);
//判断是否开启WeMedia付费阅读插件，并隐藏其付费内容
$queryPlugins= $db->select('value')->from('table.options')->where('name = ?', 'plugins'); 
$rowPlugins = $db->fetchRow($queryPlugins);
$plugins=@unserialize($rowPlugins['value']);
if(isset($plugins['activated']['WeMedia'])){
	if (preg_match_all('/&lt;!--WeMedia start--&gt;([\s\S]*?)&lt;!--WeMedia end--&gt;/i', $article["text"], $hide_content)){
		$article["text"] = str_replace($hide_content[0], "", $article["text"]);
	}
}

$smarty->assign("article",$article);
/*打赏二维码*/
$smarty->assign("dashang_qrcode",$themeOptions["dashang_qrcode"]);
/*视频字段*/
$queryFields= "SELECT * FROM ".$prefix."fields WHERE cid=".$cid." AND name='video'";
$rowFields = $db->fetchRow($queryFields);
$smarty->assign("rowFields",$rowFields);
/*热门文章*/
$rowTextHot=getHotCommentsArticle(6);
$index=0;foreach($rowTextHot as $value){
	$rowTextHot[$index]["title"]=$value["title"];
	$rowTextHot[$index]["commentsNum"]=$value["commentsNum"];
	$rowTextHot[$index]["img"]=getPostHtmImg($value['text']);
	$queryAuthor= "SELECT name,mail,screenName FROM ".$prefix."users WHERE uid=".$value['authorId'];
	$rowAuthor = $db->fetchRow($queryAuthor);
	$rowTextHot[$index]["nickname"]=$rowAuthor["screenName"]!=""?$rowAuthor["screenName"]:$rowAuthor["name"];
	$rowTextHot[$index]["avatar"]=getAuthorAvatar($rowAuthor["mail"]);
	$index++;
}
$smarty->assign("changyan_appid",$themeOptions["changyan_appid"]);
$smarty->assign("changyan_appkey",$themeOptions["changyan_appkey"]);
$smarty->assign("cid",$cid);
$smarty->assign("rowTextHot",$rowTextHot);

/*二维码*/
$qrcode=$themeOptions["head_qrcode"];
/*友情链接*/
$friends=printFriends($themeOptions["foot_friendlink"]);
/*数据统计*/
Typecho_Widget::widget('Widget_Stat')->to($stat);
$sitedata=array("categoriesNum"=>$stat->categoriesNum,"PublishedPostsNum"=>$stat->PublishedPostsNum,"PublishedPagesNum"=>$stat->PublishedPagesNum,"PublishedCommentsNum"=>$stat->PublishedCommentsNum);
/*底部信息*/
$foot_info=$themeOptions["foot_info"];
/*备案信息*/
$foot_beian=$themeOptions["foot_beian"];

$smarty->assign("cate",$cate);

$smarty->assign("favicon",$favicon);
$smarty->assign("logo",$logo);
$smarty->assign("qrcode",$qrcode);
$smarty->assign("copydate",date("Y")."-".date('Y', strtotime("+1 year")));
$smarty->assign("friends",$friends);
$smarty->assign("sitedata",$sitedata);
$smarty->assign("foot_info",$foot_info);
$smarty->assign("foot_beian",$foot_beian);
$smarty->assign("siteUrl",$options->siteUrl);
$smarty->assign("title",$options->title);
$smarty->assign("rowKeywords",$options->keywords);
$smarty->assign("rowDesc",$options->description);
$smarty->display("article.htm");
?>