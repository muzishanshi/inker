<?php
/*发送邮件*/
function sendMail($email,$title,$content){
	$db = Typecho_Db::get();
	$queryTheme= $db->select('value')->from('table.options')->where('name = ?', 'theme'); 
	$rowTheme = $db->fetchRow($queryTheme);
	require __TYPECHO_ROOT_DIR__.__TYPECHO_THEME_DIR__ . '/'.$rowTheme["value"].'/libs/email.class.php';
	$options = Typecho_Widget::widget('Widget_Options');
	$option=$options->plugin('WeMedia');
	$smtpserverport =$option->mailport;//SMTP服务器端口//企业QQ:465、126:25
	$smtpserver = $option->mailsmtp;//SMTP服务器//QQ:ssl://smtp.exmail.qq.com、126:smtp.126.com
	$smtpusermail = $option->mailuser;//SMTP服务器的用户邮箱
	$smtpemailto = $email;//发送给谁
	$smtpuser = $option->mailuser;//SMTP服务器的用户帐号
	$smtppass = $option->mailpass;//SMTP服务器的用户密码
	$mailtitle = $title;//邮件主题
	$mailcontent = $content;//邮件内容
	$mailtype = "HTML";//邮件格式（HTML/TXT）,TXT为文本邮件
	//************************ 配置信息 ****************************
	$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);//这里面的一个true是表示使用身份验证,否则不使用身份验证.
	$smtp->debug = false;//是否显示发送的调试信息
	$state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailtitle, $mailcontent, $mailtype);
	return $state;
}
/*获取文章图片*/
function getPostHtmImg($text){
	$db = Typecho_Db::get();
	$query= $db->select('value')->from('table.options')->where('name = ?', 'siteUrl'); 
	$row = $db->fetchRow($query);
	$matches_str = "/((http)+.*?((.gif)|(.jpg)|(.bmp)|(.png)|(.GIF)|(.JPG)|(.PNG)|(.BMP)))/";
	preg_match_all ($matches_str,$text,$matches,PREG_PATTERN_ORDER);
	if(isset($matches[1][0])){
		return $matches[1][0];
	}else{
		return $row["value"]."/m/resource/img/thumbnail.png";
	}
}
/*获取作者头像*/
function getAuthorAvatar($mail){
	$host = 'https://secure.gravatar.com';
	$url = '/avatar/';
	$size = '50';
	$rating = 'g';
	$hash = md5(strtolower($mail));
	$avatar = $host . $url . $hash . '?s=' . $size . '&r=' . $rating . '&d=mm';
	return $avatar;
}
/*获取热门文章*/
function getHotCommentsArticle($limit = 10){
    $db = Typecho_Db::get();
	$result = $db->fetchAll($db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('type = ?', 'post')
        ->where('table.contents.created <= unix_timestamp(now())', 'post')
        ->limit($limit)
        ->order('commentsNum', Typecho_Db::SORT_DESC)
    );
	return $result;
}
/*文章阅读次数统计*/
function get_post_view($cid) {
    $db = Typecho_Db::get();
    $prefix = $db->getPrefix();
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')))) {
        $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 0;');
        return 0;
    }
    $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
    
	$views = Typecho_Cookie::get('extend_contents_views');
	if (empty($views)) {
		$views = array();
	} else {
		$views = explode(',', $views);
	}
	if (!in_array($cid, $views)) {
		$db->query($db->update('table.contents')->rows(array('views' => (int)$row['views'] + 1))->where('cid = ?', $cid));
		array_push($views, $cid);
		$views = implode(',', $views);
		Typecho_Cookie::set('extend_contents_views', $views);
	}
    return $row['views'];
}
function getThemeOptions(){
	$themeOption = "";
	if ($themeOption == "") {
		$db = Typecho_Db::get();
		$queryTheme= $db->select('value')->from('table.options')->where('name = ?', 'theme'); 
		$rowTheme = $db->fetchRow($queryTheme);
		$query = $db->select('value')->from('table.options')->where('name = ?', 'theme:'.$rowTheme["value"]);
		$result = $db->fetchAll($query);
		$themeOption = unserialize($result[0]["value"]);
		unset($db);
	}
	return $themeOption;
}
/*输出友情链接*/
function printFriends($link){
	?>
	<style>
	.friendlink{margin:0 auto;width:calc(100% - 100px);}
	@media screen and (max-width:calc(100% - 100px);) {
		.friendlink{width: calc(100% - 100px);}
	}
	</style>
	<?php
	$friendlink=json_decode($link,true);
	if(isset($friendlink)){
		$friendlinks='<div class="friendlink"><marquee direction="up" behavior="scroll" scrollamount="1" scrolldelay="10" loop="-1" onMouseOver="this.stop()" onMouseOut="this.start()" width="100%" height="30" style="text-align:center;">友情链接：';
		array_multisort(array_column($friendlink, 'order'), SORT_DESC, $friendlink);
		$isHaveLink=false;
		foreach($friendlink as $value){
			if($value["name"]!=null&&$value["link"]!=null&&$value["type"]=="home"){
				$isHaveLink=true;
				$icon=$value["icon"]!=""?$value["icon"]:"0";
				$iconlink=is_numeric($icon)?'https://wpa.qq.com/msgrd?v=3&uin='.$icon.'&site=qq&menu=yes':$value["link"];
				$iconimg=is_numeric($icon)?'https://q1.qlogo.cn/g?b=qq&nk='.$icon.'&s=100':$icon;
				$friendlinks.='<a href=javascript:open("'.$iconlink.'");><img src="'.$iconimg.'" width="16" /></a><a href="'.$value["link"].'" target="'.$value["target"].'" title="'.$value["detail"].'" rel="'.$value["rel"].'">'.$value["name"].'</a>&nbsp;';
			}
		}
		$friendlinks.='</marquee></div>';
		if(!$isHaveLink){
			$friendlinks='';
		}
		return $friendlinks;
	}
}
?>