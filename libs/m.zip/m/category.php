<?php
require_once "config/public_function.php";
include_once "../config.inc.php";
include_once "include/function.php";

$db = Typecho_Db::get();
$prefix=$db->getPrefix();
$options=Typecho_Widget::widget('Widget_Options');
$themeOptions=getThemeOptions();

$mid = isset($_GET['mid']) ? addslashes(trim($_GET['mid'])) : 0;
$keyword = isset($_GET['keyword']) ? addslashes(trim($_GET['keyword'])) : "";

/*favicon*/
$favicon=$themeOptions["head_favicon"];
/*LOGO*/
$logo=$themeOptions["head_logo_img"];
/*分类导航*/
Typecho_Widget::widget('Widget_Metas_Category_List')->to($category);
$i=0;while($category->next()){
	if($category->parent!=0){continue;}
	$cate[$i]["mid"]=$category->mid;
	$cate[$i]["name"]=$category->name;
	$i++;
}

/*文章列表*/
//Typecho_Widget::widget('Widget_Contents_Post_Recent','pageSize=12&type=category','mid='.$mid)->to($post);
$queryMetas= "SELECT * FROM ".$prefix."metas WHERE parent=".$mid;
$rowMetas = $db->fetchAll($queryMetas);
$metas="(";
foreach($rowMetas as $value){
	$metas.=$value["mid"].",";
}
$metas.=$mid.")";

$page_now = isset($_GET['page_now']) ? addslashes($_GET['page_now']) : 1;
if($page_now<1){
	$page_now=1;
}
if($keyword){
	$query = $db->select('*','table.contents.cid as ccid','table.contents.created as ccreated')->from('table.contents')
		->join('table.users', 'table.contents.authorId = table.users.uid',Typecho_Db::INNER_JOIN)
		->join('table.relationships', 'table.relationships.cid = table.contents.cid',Typecho_Db::INNER_JOIN)
		->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)
		->where('table.contents.type = ?', 'post')
		->where('table.contents.status = ?', 'publish')
		->where('table.metas.type = ?', 'category')
		->where('table.contents.title like "%'.$keyword.'%" OR table.contents.text like "%'.$keyword.'%"');
}else{
	$query = $db->select('*','table.contents.cid as ccid','table.contents.created as ccreated')->from('table.contents')
		->join('table.users', 'table.contents.authorId = table.users.uid',Typecho_Db::INNER_JOIN)
		->join('table.relationships', 'table.relationships.cid = table.contents.cid',Typecho_Db::INNER_JOIN)
		->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)
		->where('table.contents.type = ?', 'post')
		->where('table.contents.status = ?', 'publish')
		->where('table.metas.type = ?', 'category')
		->where('table.relationships.mid in '.$metas);
}
$resultTotal = $db->fetchAll($query);
$page_rec=18;
$totalrec=count($resultTotal);
$page=ceil($totalrec/$page_rec);

$arr['totalItem'] = $totalrec;
$arr['pageSize'] = $page_rec;
$arr['totalPage'] = $page;

if($page_now>$page){
	$page_now=$page;
}
if($page_now<=1){
	$before_page=1;
	if($page>1){
		$after_page=$page_now+1;
	}else{
		$after_page=1;
	}
}else{
	$before_page=$page_now-1;
	if($page_now<$page){
		$after_page=$page_now+1;
	}else{
		$after_page=$page;
	}
}
$i=($page_now-1)*$page_rec<0?0:($page_now-1)*$page_rec;
if($keyword){
	$query = $db->select('*','table.contents.cid as ccid','table.contents.created as ccreated')->from('table.contents')
		->join('table.users', 'table.contents.authorId = table.users.uid',Typecho_Db::INNER_JOIN)
		->join('table.relationships', 'table.relationships.cid = table.contents.cid',Typecho_Db::INNER_JOIN)
		->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)
		->where('table.contents.type = ?', 'post')
		->where('table.contents.status = ?', 'publish')
		->where('table.metas.type = ?', 'category')
		->where('table.contents.title like "%'.$keyword.'%" OR table.contents.text like "%'.$keyword.'%"')
		->order('ccreated',Typecho_Db::SORT_DESC)
		->offset($i)->limit($page_rec);
}else{
	$query = $db->select('*','table.contents.cid as ccid','table.contents.created as ccreated')->from('table.contents')
		->join('table.users', 'table.contents.authorId = table.users.uid',Typecho_Db::INNER_JOIN)
		->join('table.relationships', 'table.relationships.cid = table.contents.cid',Typecho_Db::INNER_JOIN)
		->join('table.metas', 'table.relationships.mid = table.metas.mid',Typecho_Db::INNER_JOIN)
		->where('table.contents.type = ?', 'post')
		->where('table.contents.status = ?', 'publish')
		->where('table.metas.type = ?', 'category')
		->where('table.relationships.mid in '.$metas)
		->order('ccreated',Typecho_Db::SORT_DESC)
		->offset($i)->limit($page_rec);
}
$rows = $db->fetchAll($query);
$articleList=array();
$index=0;foreach($rows as $value){
	$articleList[$index]["uid"]=$value["uid"];
	$articleList[$index]["cid"]=$value["ccid"];
	$articleList[$index]["title"]=$value["title"];
	$articleList[$index]["nickname"]=$value["screenName"]!=""?$value["screenName"]:$value["name"];
	$articleList[$index]["commentsNum"]=$value["commentsNum"];
	$articleList[$index]["created"]=date("Y-m-d",$value["ccreated"]);
	$articleList[$index]["img"]=getPostHtmImg($value["text"]);
	$articleList[$index]["avatar"]=getAuthorAvatar($value["mail"]);
	$index++;
}
$smarty->assign("mid",$mid);
$smarty->assign("keyword",$keyword);
$smarty->assign("page_now",$page_now);
$smarty->assign("totalrec",$totalrec);
$smarty->assign("before_page",$before_page);
$smarty->assign("after_page",$after_page);
$smarty->assign("page_rec",$page_rec);
$smarty->assign("page",$page);
$smarty->assign("articleList",$articleList);

/*二维码*/
$qrcode=$themeOptions["head_qrcode"];
/*友情链接*/
$friends=printFriends($themeOptions["foot_friendlink"]);
/*数据统计*/
Typecho_Widget::widget('Widget_Stat')->to($stat);
$sitedata=array("categoriesNum"=>$stat->categoriesNum,"PublishedPostsNum"=>$stat->PublishedPostsNum,"PublishedPagesNum"=>$stat->PublishedPagesNum,"PublishedCommentsNum"=>$stat->PublishedCommentsNum);
/*底部信息*/
$foot_info=$themeOptions["foot_info"];
/*备案信息*/
$foot_beian=$themeOptions["foot_beian"];

$smarty->assign("cate",$cate);

$smarty->assign("favicon",$favicon);
$smarty->assign("logo",$logo);
$smarty->assign("qrcode",$qrcode);
$smarty->assign("copydate",date("Y")."-".date('Y', strtotime("+1 year")));
$smarty->assign("friends",$friends);
$smarty->assign("sitedata",$sitedata);
$smarty->assign("foot_info",$foot_info);
$smarty->assign("foot_beian",$foot_beian);
$smarty->assign("siteUrl",$options->siteUrl);
$smarty->assign("title",$options->title);
$smarty->assign("rowKeywords",$options->keywords);
$smarty->assign("rowDesc",$options->description);
$smarty->display("category.htm");
?>