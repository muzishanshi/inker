<?php
session_start();
header("Content-type: text/html; charset=utf-8"); 
require_once "libs/Smarty.class.php";
$smarty=new Smarty();
$smarty->left_delimiter="^";
$smarty->right_delimiter="^";
$smarty->config_dir="config/";
$smarty->template_dir="templates/";
$smarty->compile_dir="libs/templates_c/";
$smarty->cache_dir="libs/cache/";
$smarty->plugins_dir="libs/plugins/";
$smarty->compile_check=true;
$smarty->debugging=false;
?>