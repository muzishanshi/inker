<?php
require_once "config/public_function.php";
include_once "../config.inc.php";
include_once "include/function.php";

$db = Typecho_Db::get();
$prefix=$db->getPrefix();
$options=Typecho_Widget::widget('Widget_Options');
$themeOptions=getThemeOptions();

/*favicon*/
$favicon=$themeOptions["head_favicon"];
/*LOGO*/
$logo=$themeOptions["head_logo_img"];
/*判断是否开启CateFilter首页过滤指定分类插件，并隐藏其所选分类*/
$cateIdStr="";
$CateIdArr=array();
$queryPlugins= $db->select('value')->from('table.options')->where('name = ?', 'plugins'); 
$rowPlugins = $db->fetchRow($queryPlugins);
$plugins=@unserialize($rowPlugins['value']);
if(isset($plugins['activated']['CateFilter'])){
	$pluginCateFilter=$options->plugin('CateFilter');
	$CateIds = $pluginCateFilter->CateId;
	if($CateIds){
		$CateIds = explode(',', $CateIds);
        $CateIdArr = array_unique($CateIds);
		foreach ($CateIdArr as $k => $v) {
			$cateIdStr.=intval($v).",";
		}
		$cateIdStr=substr($cateIdStr, 0, -1);
	}
}
if($cateIdStr){
	$hideCateStr=" AND r.mid not in (".$cateIdStr.")";
}else{
	$hideCateStr="";
}

/*分类导航*/
Typecho_Widget::widget('Widget_Metas_Category_List')->to($category);
$cate=array();$i=0;while($category->next()){
	if($category->parent!=0){continue;}
	$cate[$i]["mid"]=$category->mid;
	$cate[$i]["name"]=$category->name;
	
	//首页按分类分组文章列表
	$queryMetas= "SELECT * FROM ".$prefix."metas WHERE parent=".$category->mid;
	$rowMetas = $db->fetchAll($queryMetas);
	$metas="(";
	foreach($rowMetas as $value){
		$metas.=$value["mid"].",";
	}
	$metas.=$category->mid.")";
	$query= "SELECT *,c.cid as ccid,c.created as ccreated,r.mid as rmid FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid INNER JOIN ".$prefix."relationships AS r ON c.cid = r.cid INNER JOIN ".$prefix."metas AS m ON m.mid = r.mid WHERE c.type='post' AND c.status='publish' AND m.type='category' AND r.mid in ".$metas.$hideCateStr." ORDER BY c.created DESC LIMIT 0,9";
	$rows = $db->fetchAll($query);
	$j=0;foreach($rows as $value){
		$newrows[$j]["uid"]=$value["uid"];
		$newrows[$j]["mid"]=$value["rmid"];
		$newrows[$j]["cid"]=$value["ccid"];
		$newrows[$j]["title"]=$value["title"];
		$newrows[$j]["nickname"]=$value["screenName"]!=""?$value["screenName"]:$value["name"];
		$newrows[$j]["commentsNum"]=$value["commentsNum"];
		$newrows[$j]["created"]=date("Y-m-d",$value["ccreated"]);
		$newrows[$j]["img"]=getPostHtmImg($value["text"]);
		$newrows[$j]["avatar"]=getAuthorAvatar($value["mail"]);
		$j++;
	}
	$cate[$i]["data"]=$newrows;
	
	$i++;
}

/*最新文章*/
//Typecho_Widget::widget('Widget_Contents_Post_Recent','pageSize=17')->to($post);
$query= "SELECT *,c.cid as ccid,c.created as ccreated FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid INNER JOIN ".$prefix."relationships AS r ON c.cid = r.cid INNER JOIN ".$prefix."metas AS m ON m.mid = r.mid WHERE c.type='post' AND c.status='publish' AND m.type='category'".$hideCateStr." ORDER BY c.created DESC LIMIT 0,17";
$posts = $db->fetchAll($query);
$index=0;foreach($posts as $post){
	if($index==0){
		$smarty->assign("rowNew_1_uid",$post["uid"]);
		$smarty->assign("rowNew_1_cid",$post["ccid"]);
		$smarty->assign("rowNew_1_created",date("Y-m-d",$post["ccreated"]));
		$smarty->assign("rowNew_1_commentsNum",$post["commentsNum"]);
		$smarty->assign("rowNew_1_nickname",$post["screenName"]!=""?$post["screenName"]:$post["name"]);
		$smarty->assign("rowNew_1_title",$post["title"]);
		$smarty->assign("rowNew_1_img",getPostHtmImg($post["text"]));
		$smarty->assign("rowNew_1_avatar",getAuthorAvatar($post["mail"]));
	}else if($index>0&&$index<=2){
		$rowNew_2[$index]["uid"]=$post["uid"];
		$rowNew_2[$index]["cid"]=$post["ccid"];
		$rowNew_2[$index]["title"]=$post["title"];
		$rowNew_2[$index]["nickname"]=$post["screenName"]!=""?$post["screenName"]:$post["name"];
		$rowNew_2[$index]["commentsNum"]=$post["commentsNum"];
		$rowNew_2[$index]["created"]=date("Y-m-d",$post["ccreated"]);
		$rowNew_2[$index]["img"]=getPostHtmImg($post["text"]);
		$rowNew_2[$index]["avatar"]=getAuthorAvatar($post["mail"]);
		$smarty->assign("rowNew_2",$rowNew_2);
	}else if($index>2&&$index<=4){
		$rowNew_3[$index]["uid"]=$post["uid"];
		$rowNew_3[$index]["cid"]=$post["ccid"];
		$rowNew_3[$index]["title"]=$post["title"];
		$rowNew_3[$index]["nickname"]=$post["screenName"]!=""?$post["screenName"]:$post["name"];
		$rowNew_3[$index]["commentsNum"]=$post["commentsNum"];
		$rowNew_3[$index]["created"]=date("Y-m-d",$post["ccreated"]);
		$rowNew_3[$index]["img"]=getPostHtmImg($post["text"]);
		$rowNew_3[$index]["avatar"]=getAuthorAvatar($post["mail"]);
		$smarty->assign("rowNew_3",$rowNew_3);
	}else if($index>4&&$index<=17){
		$rowNew_4[$index]["uid"]=$post["uid"];
		$rowNew_4[$index]["cid"]=$post["ccid"];
		$rowNew_4[$index]["title"]=$post["title"];
		$rowNew_4[$index]["nickname"]=$post["screenName"]!=""?$post["screenName"]:$post["name"];
		$rowNew_4[$index]["commentsNum"]=$post["commentsNum"];
		$rowNew_4[$index]["created"]=date("Y-m-d",$post["ccreated"]);
		$rowNew_4[$index]["img"]=getPostHtmImg($post["text"]);
		$rowNew_4[$index]["avatar"]=getAuthorAvatar($post["mail"]);
		$smarty->assign("rowNew_4",$rowNew_4);
	}
	$index++;
}

/*排行榜*/
//$rowTextHot=getHotCommentsArticle(5);
$queryTextHot= "SELECT *,c.cid as ccid,c.created as ccreated FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid INNER JOIN ".$prefix."relationships AS r ON c.cid = r.cid INNER JOIN ".$prefix."metas AS m ON m.mid = r.mid WHERE c.type='post' AND c.status='publish' AND m.type='category'".$hideCateStr." ORDER BY commentsNum DESC,c.created DESC LIMIT 0,5";
$rowTextHot = $db->fetchAll($queryTextHot);
$index=0;foreach($rowTextHot as $value){
	$rowTextHot[$index]["title"]=$value["title"];
	$rowTextHot[$index]["commentsNum"]=$value["commentsNum"];
	$rowTextHot[$index]["img"]=getPostHtmImg($value['text']);
	$index++;
}

Typecho_Widget::widget('Widget_Users_Admin','pageSize=5')->to($users);
$rowUserNew=array();$index=0;while($users->next()){
	$rowUserNew[$index]["uid"]=$users->uid;
	$rowUserNew[$index]["nickname"]=$users->screenName!=""?$users->screenName:$users->name;
	$rowUserNew[$index]["mail"]=$users->mail;
	$rowUserNew[$index]["avatar"]=getAuthorAvatar($users->mail);
	$index++;
}
$rowUserNew=array_reverse($rowUserNew);

//Typecho_Widget::widget('Widget_Comments_Recent','pageSize=5')->to($comments);
$rowCommentNew=array();
$queryCommentNew= "SELECT *,c.cid as ccid,c.created as ccreated,cs.authorId as csauthorId,cs.text as cstext FROM ".$prefix."contents AS c INNER JOIN ".$prefix."comments AS cs ON cs.cid = c.cid INNER JOIN ".$prefix."relationships AS r ON c.cid = r.cid INNER JOIN ".$prefix."metas AS m ON m.mid = r.mid WHERE c.type='post' AND c.status='publish' AND cs.status='approved' AND cs.type='comment' AND m.type='category'".$hideCateStr." ORDER BY coid DESC LIMIT 0,5";
$rowCommentNew = $db->fetchAll($queryCommentNew);
$index=0;foreach($rowCommentNew as $comments){
	$rowCommentNew[$index]["authorId"]=$comments["csauthorId"];
	$rowCommentNew[$index]["cid"]=$comments["ccid"];
	$rowCommentNew[$index]["author"]=$comments["author"];
	$rowCommentNew[$index]["text"]=$comments["cstext"];
	$rowCommentNew[$index]["avatar"]=getAuthorAvatar($comments["mail"]);
	$index++;
}

/*二维码*/
$qrcode=$themeOptions["head_qrcode"];
/*友情链接*/
$friends=printFriends($themeOptions["foot_friendlink"]);
/*数据统计*/
Typecho_Widget::widget('Widget_Stat')->to($stat);
$sitedata=array("categoriesNum"=>$stat->categoriesNum,"PublishedPostsNum"=>$stat->PublishedPostsNum,"PublishedPagesNum"=>$stat->PublishedPagesNum,"PublishedCommentsNum"=>$stat->PublishedCommentsNum);
/*底部信息*/
$foot_info=$themeOptions["foot_info"];
/*备案信息*/
$foot_beian=$themeOptions["foot_beian"];

$smarty->assign("cate",$cate);
$smarty->assign("rowTextHot",$rowTextHot);
$smarty->assign("rowUserNew",$rowUserNew);
$smarty->assign("rowCommentNew",$rowCommentNew);

$smarty->assign("favicon",$favicon);
$smarty->assign("logo",$logo);
$smarty->assign("qrcode",$qrcode);
$smarty->assign("copydate",date("Y")."-".date('Y', strtotime("+1 year")));
$smarty->assign("friends",$friends);
$smarty->assign("sitedata",$sitedata);
$smarty->assign("foot_info",$foot_info);
$smarty->assign("foot_beian",$foot_beian);
$smarty->assign("siteUrl",$options->siteUrl);
$smarty->assign("title",$options->title);
$smarty->assign("rowKeywords",$options->keywords);
$smarty->assign("rowDesc",$options->description);
$smarty->display("index.htm");
?>