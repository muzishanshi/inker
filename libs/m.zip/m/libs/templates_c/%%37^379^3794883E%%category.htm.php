<?php /* Smarty version 2.6.18, created on 2019-02-15 10:37:06
         compiled from category.htm */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="main">
    <div class="container">
		<?php if ($this->_tpl_vars['totalrec'] > 0): ?>
			<div class="flex">
				<?php $_from = $this->_tpl_vars['articleList']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['articleList'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['articleList']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['articleList']['iteration']++;
?>
				<div class="flex-item flex-item-half-xs flex-item-order-xs-4 flex-item-order-sm-5 flex-item-order-md-5 flex-item-order-lg-5">
					<div class="img-box img-box-sm">
						<div class="pic">
							<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
">
								<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
								<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
								<span class="play"><i></i></span>
							</a>
							<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
						</div>
						<div class="user">
							<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
							<span class="name no-wrap">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
									<?php echo $this->_tpl_vars['k']['nickname']; ?>

								</a>
							</span>
						</div>
						<div class="tags">
							<p></p>
						</div>
					</div>
				</div>
				<?php endforeach; endif; unset($_from); ?>
			</div>
			<nav aria-label="Page navigation">
			  <ul class="pagination">
				<?php if ($this->_tpl_vars['page_now'] > 1): ?>
				<li>
				  <a href="?mid=<?php echo $this->_tpl_vars['mid']; ?>
&keyword=<?php echo $this->_tpl_vars['keyword']; ?>
&page_now=<?php echo $this->_tpl_vars['before_page']; ?>
" aria-label="Previous">
					<span aria-hidden="true">&laquo; 上一页</span>
				  </a>
				</li>
				<?php endif; ?>
				<?php if ($this->_tpl_vars['page_now'] < $this->_tpl_vars['page']): ?>
				<li>
				  <a href="?mid=<?php echo $this->_tpl_vars['mid']; ?>
&keyword=<?php echo $this->_tpl_vars['keyword']; ?>
&page_now=<?php echo $this->_tpl_vars['after_page']; ?>
" aria-label="Next">
					<span aria-hidden="true">下一页 &raquo;</span>
				  </a>
				</li>
				<?php endif; ?>
			  </ul>
			</nav>
		<?php else: ?>
			<p>该分类下暂无内容，过几天再来吧⌒_⌒</p>
		<?php endif; ?>
    </div>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>