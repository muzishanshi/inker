<?php /* Smarty version 2.6.18, created on 2019-02-15 10:52:02
         compiled from author.htm */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="main">
    <div class="banner">
		<div class="container">
			<div class="avatar" style="background-image: url(<?php echo $this->_tpl_vars['user']['avatar']; ?>
)"></div>
			<div class="infos">
				<h1><?php echo $this->_tpl_vars['user']['nickname']; ?>
<i class="sex sex_man"></i></h1>
				<p><span>ID：<?php echo $this->_tpl_vars['user']['uid']; ?>
</span><span>邮箱：<?php echo $this->_tpl_vars['user']['mail']; ?>
</span></p>
				<p class="tags">网址：<?php echo $this->_tpl_vars['user']['url']; ?>
</p>
				<div class="btns">
					<a href="javascript:;" target="_blank" class="btn btn-download" rel="nofollow" data-type="download" id="dashang">打赏</a>
					<div class="qrcode2" style="background:url('<?php echo $this->_tpl_vars['dashang_qrcode']; ?>
');background-size: 117px 100px;width: 117px;height: 100px;position: relative;top: -38px;left: 90px;display: none;"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="anchor_detail">
			<div class="tabs">
				<a href="javascript:void(0);"></a>
			</div>
			<div class="content">
				<!--
				<h2 class="sub-title">基本档案</h2>
				<div class="infos1">
				</div>
				-->
				<h2 class="sub-title">我的近况</h2>
				<?php if ($this->_tpl_vars['totalrec'] > 0): ?>
					<div class="flex">
						<?php $_from = $this->_tpl_vars['authorArticle']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['authorArticle'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['authorArticle']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['authorArticle']['iteration']++;
?>
						<div class="flex-item flex-item-half-xs">
							<div class="img-box img-box-sm">
								<div class="pic">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
" target="_blank" rel="nofollow" data-type="download">
										<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
										<span class="play"><i></i></span>
									</a>
									<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
								</div>
								<a class="user" href="javascript:;">
									<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
									<span class="name no-wrap"><?php echo $this->_tpl_vars['k']['nickname']; ?>
</span>
								</a>
								<div class="tags">
									<p></p>
								</div>
							</div>
						</div>
						<?php endforeach; endif; unset($_from); ?>
					</div>
					<nav aria-label="Page navigation">
					  <ul class="pagination">
						<?php if ($this->_tpl_vars['page_now'] > 1): ?>
						<li>
						  <a href="?uid=<?php echo $this->_tpl_vars['uid']; ?>
&page_now=<?php echo $this->_tpl_vars['before_page']; ?>
" aria-label="Previous">
							<span aria-hidden="true">&laquo; 上一页</span>
						  </a>
						</li>
						<?php endif; ?>
						<?php if ($this->_tpl_vars['page_now'] < $this->_tpl_vars['page']): ?>
						<li>
						  <a href="?uid=<?php echo $this->_tpl_vars['uid']; ?>
&page_now=<?php echo $this->_tpl_vars['after_page']; ?>
" aria-label="Next">
							<span aria-hidden="true">下一页 &raquo;</span>
						  </a>
						</li>
						<?php endif; ?>
					  </ul>
					</nav>
				<?php else: ?>
					<p>此人有一些懒，还未发表过内容哦~⌒_⌒</p>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>