<?php /* Smarty version 2.6.18, created on 2019-02-15 17:02:31
         compiled from header.htm */ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="applicable-device" content="pc,mobile"/>
    <meta name="keywords" content="<?php echo $this->_tpl_vars['rowKeywords']; ?>
">
    <meta name="description" content="<?php echo $this->_tpl_vars['rowDesc']; ?>
">
    <title><?php echo $this->_tpl_vars['title']; ?>
</title>
    <link rel="shortcut icon" href="<?php echo $this->_tpl_vars['favicon']; ?>
" type="image/x-icon" />
    <link href="resource/css/bootstrap.min.css" rel="stylesheet">
    <link href="resource/css/base.css" rel="stylesheet">
	<link href="resource/css/index.css" rel="stylesheet" >
	<link href="resource/css/iconfont.css" rel="stylesheet" >
	<script src="resource/js/jquery.min.js"></script>
    <!--[if lt IE 9]>
    <script src="resource/js/html5shiv.min.js"></script>
    <script src="resource/js/respond.min.js"></script>
    <script src="resource/js/jquery.nicescroll.js"></script>
    <![endif]-->
</head>
<body>
<nav class="navbar navbar-default navbar-inke">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" style="background:url('<?php echo $this->_tpl_vars['logo']; ?>
') no-repeat;padding: 0;margin: 26px 60px 24px 0;width: 156px;height: 40px;background-size: 156px 40px;" href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m" title="<?php echo $this->_tpl_vars['title']; ?>
"></a>
        </div>
        <div class="collapse navbar-collapse" id="navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
"><span>网站首页</span></a></li>
				<?php $_from = $this->_tpl_vars['cate']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['cate'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['cate']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['cate']['iteration']++;
?>
                <li><a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/category.php?mid=<?php echo $this->_tpl_vars['k']['mid']; ?>
"><span><?php echo $this->_tpl_vars['k']['name']; ?>
</span></a></li>
                <?php endforeach; endif; unset($_from); ?>
            </ul>
			<div class="nav navbar-nav navbar-right searchDiv">
				<a class="searchButton"  id="sousuo" onclick="$.Sousuo()"><i class="iconfont icon-aria-search" id="nav-search-btn"></i></a>
				<form class="js-search search-form search-form--modal" action="category.php" method="get" role="search">
					<div class="search-form__inner">
						<div>
							<p class="micro mb-">输入后按回车搜索 ...</p>
							<i class="icon-search"></i>
							<input id="keyword" class="text-input" type="search" name="keyword" placeholder="Search" required="">
						</div>
					</div>
					<div class="search_close" onclick="$.Close()"></div>
				</form>
				<script>
				$.extend({
					Sousuo: function() {
						$('.js-toggle-search').toggleClass('is-active');
						$('.js-search').toggleClass('is-visible');
					},
					Close: function(){
						if($('.js-search').hasClass('is-visible')){
							$('.js-toggle-search').toggleClass('is-active');
							$('.js-search').toggleClass('is-visible');
						}
					},
				});
				</script>
			</div>
            <ul class="nav navbar-nav navbar-right" style="display:none;">
                <li><a href="login.php"><span>登录</span></a></li>
            </ul>
        </div>
    </div>
</nav>