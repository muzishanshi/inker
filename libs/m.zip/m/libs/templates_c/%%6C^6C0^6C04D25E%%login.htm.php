<?php /* Smarty version 2.6.18, created on 2019-02-15 23:53:55
         compiled from login.htm */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div id="container" class="pay_wrapper">
	<div class="pay_box">
		<ul class="pay_tab clearfix">
			<li class="active">用户登录</li>
		</ul>
		<div class="pay_cont">
			<form id="loginForm" action="<?php echo $this->_tpl_vars['loginAction']; ?>
" method="post">
				<div class="pay_choose pay_free">
					<h4>
						电子邮箱&nbsp;&nbsp;<small id="mailmsg"></small>
						<span style="font-size: 13px;"></span>
					</h4>
					<div class="box-ipt">
						<input type="text" id="loginMail" name="mail" placeholder="请输入邮箱" class="ipt-free"/>
					</div>
					<?php if ($this->_tpl_vars['isShowSmsCode'] == true): ?>
					<h4>
						邮箱验证码&nbsp;&nbsp;
						<span style="font-size: 13px;">
							<a id="sendMail" href="javascript:;">发送</a>
							<a id="sendMailHidden" href="javascript:;" style="display:none;">发送</a>
						</span>
						<small id="codemsg"></small>
					</h4>
					<div class="box-ipt">
						<input type="text" id="loginCode" name="code" placeholder="请输入验证码" class="ipt-free"/>
					</div>
					<?php endif; ?>
					<h4>
						密码&nbsp;&nbsp;<small id="pwdmsg"></small>
						<span style="font-size: 13px;"></span>
					</h4>
					<div class="box-ipt">
						<input type="password" id="loginPwd" name="password" placeholder="请输入密码" class="ipt-free"/>
					</div>
				</div>
				<div class="to_pay clearfix">
					<small id="loginmsg"></small>
					<span id="topay">登陆</span>
					<input type="hidden" name="action" value="submitlogin" />
				</div>
			</form>
		</div>
	</div>
	<script>
	$('#sendMail').click(function() {
		settime();
		$.post("login.php",{action:"sendMail",mail:$("#loginMail").val()},function(data){
			var data=JSON.parse(data);
			if(data.error_code==0){
				$("#codemsg").html('<font color="green">'+data.message+'</font>');
			}else{
				$("#codemsg").html('<font color="red">'+data.message+'</font>');
			}
		});
	});
	var timer;
	var countdown=60;
	function settime() {
		if (countdown == 0) {
			countdown = 60;
			clearTimeout(timer);
			$("#sendMail").css("display","inline");
			$("#sendMailHidden").css("display","none");
			return;
		} else {
			$("#sendMail").css("display","none");
			$("#sendMailHidden").css("display","inline");
			$("#sendMailHidden").html(countdown+'秒后可重新发送');
			countdown--; 
		} 
		timer=setTimeout(function() { 
			settime() 
		},1000) 
	}
	$('#topay').click(function() {
		if($("#loginMail").val()==""){
			$("#mailmsg").html('<font color="red">请填写邮箱</font>');
			return;
		}
		if($("#loginPwd").val()==""){
			$("#pwdmsg").html('<font color="red">请填写密码</font>');
			return;
		}
		$.post("login.php",{action:"ajaxlogin",mail:$('#loginMail').val(),password:$('#loginPwd').val(),code:$('#loginCode').val()},function(data){
			var data=JSON.parse(data);
			if(data.error_code==0){
				$("#loginmsg").html('<font color="green">'+data.message+'</font>');
				//$('#loginForm').submit();
				$.ajax({
					url: $(".login_form").attr("action"),
					type: $(".login_form").attr("method"),
					data: $(".login_form").serializeArray(),
					success: function(data) {
						location.reload();
					},
					error: function() {
						$("#loginmsg").html('<font color="green">登录错误！</font>');
					}
				});
			}else{
				$("#loginmsg").html('<font color="red">'+data.message+'</font>');
			}
		});
	});
	</script>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>