<?php /* Smarty version 2.6.18, created on 2019-02-15 11:18:39
         compiled from article.htm */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="main">
    <div class="banner">
		<div class="container">
			<div class="avatar"<?php if ($this->_tpl_vars['rowFields']['str_value'] == ""): ?> style="background-image: url(<?php echo $this->_tpl_vars['article']['avatar']; ?>
)"<?php endif; ?>>
				<?php if ($this->_tpl_vars['rowFields']['str_value'] != ""): ?>
				<video src="http://mvvideo11.meitudata.com/5c64d83dddb96qpcxfab7w8192_H264_1_6c03545f90f336.mp4?k=926be9e137169b29cdadec382d383124&t=5c697f0c" style="width:250px;height:250px;" controls="controls">您的浏览器不支持 video 标签。</video>
				<?php endif; ?>
			</div>
			<div class="infos">
				<h4><?php echo $this->_tpl_vars['article']['title']; ?>
<i class="sex sex_man"></i></h4>
				<p>
					<span>时间：<?php echo $this->_tpl_vars['article']['created']; ?>
</span>
					<span>作者：<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['article']['uid']; ?>
"><?php echo $this->_tpl_vars['article']['nickname']; ?>
</a></span>
					<span>评论：<?php echo $this->_tpl_vars['article']['commentsNum']; ?>
</span>
					<span>阅读：<?php echo $this->_tpl_vars['article']['viewsNum']; ?>
</span>
				</p>
				<p class="tags"></p>
				<div class="btns">
					<a href="javascript:;" target="_blank" class="btn btn-download" rel="nofollow" data-type="download" id="dashang">打赏</a>
					<div class="qrcode2" style="background:url('<?php echo $this->_tpl_vars['dashang_qrcode']; ?>
');background-size: 117px 100px;width: 117px;height: 100px;position: relative;top: -38px;left: 90px;display: none;"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="anchor_detail">
			<div class="tabs">
				<a href="javascript:void(0);"></a>
			</div>
			<div class="content">
				<h2 class="sub-title">文章内容</h2>
				<div class="infos1">
					<?php echo $this->_tpl_vars['article']['text']; ?>

				</div>
				<?php if ($this->_tpl_vars['changyan_appid'] != "" && $this->_tpl_vars['changyan_appkey'] != ""): ?>
				<h2 class="sub-title">文章评论</h2>
				<div class="infos1">
					<div id="SOHUCS" sid="<?php echo $this->_tpl_vars['cid']; ?>
" ></div> 
					<script type="text/javascript"> 
					(function(){ 
					var appid = '<?php echo $this->_tpl_vars['changyan_appid']; ?>
'; 
					var conf = '<?php echo $this->_tpl_vars['changyan_appkey']; ?>
'; 
					var width = window.innerWidth || document.documentElement.clientWidth; 
					if (width < 960) { 
					window.document.write('<script id="changyan_mobile_js" charset="utf-8" type="text/javascript" src="https://changyan.sohu.com/upload/mobile/wap-js/changyan_mobile.js?client_id=' + appid + '&conf=' + conf + '"><\/script>'); } else { var loadJs=function(d,a){var c=document.getElementsByTagName("head")[0]||document.head||document.documentElement;var b=document.createElement("script");b.setAttribute("type","text/javascript");b.setAttribute("charset","UTF-8");b.setAttribute("src",d);if(typeof a==="function"){if(window.attachEvent){b.onreadystatechange=function(){var e=b.readyState;if(e==="loaded"||e==="complete"){b.onreadystatechange=null;a()}}}else{b.onload=a}}c.appendChild(b)};loadJs("https://changyan.sohu.com/upload/changyan.js",function(){window.changyan.api.config({appid:appid,conf:conf})}); } })();
					</script>
				</div>
				<?php endif; ?>
				<h2 class="sub-title">热门文章</h2>
				<div class="flex">
					<?php $_from = $this->_tpl_vars['rowTextHot']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowTextHot'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowTextHot']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowTextHot']['iteration']++;
?>
					<div class="flex-item flex-item-half-xs">
						<div class="img-box img-box-sm">
							<div class="pic">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
" target="_blank" rel="nofollow" data-type="download">
									<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
									<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
									<span class="play"><i></i></span>
								</a>
								<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
							</div>
							<a class="user" href="javascript:;">
								<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
								<span class="name no-wrap"><?php echo $this->_tpl_vars['k']['nickname']; ?>
</span>
							</a>
							<div class="tags">
								<p></p>
							</div>
						</div>
					</div>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>