<?php /* Smarty version 2.6.18, created on 2019-02-15 09:05:56
         compiled from index.htm */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div class="main">
    <div class="container">
		<div class="flex">
			<div class="flex-item flex-item-all-xs flex-item-order-xs-1 flex-item-order-sm-1 flex-item-order-md-1 flex-item-order-lg-1">
				<h2 class="sub-title">最新文章</h2>
				<div class="img-box img-box-lg">
					<div class="pic">
						<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['rowNew_1_cid']; ?>
">
							<img src="<?php echo $this->_tpl_vars['rowNew_1_img']; ?>
" alt="<?php echo $this->_tpl_vars['rowNew_1_nickname']; ?>
">
							<p class="views"><span><?php echo $this->_tpl_vars['rowNew_1_created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['rowNew_1_commentsNum']; ?>
</span>
							<span class="play"><i></i></span>
						</a>
						<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['rowNew_1_title']; ?>
</p></div>
					</div>
					<div class="user">
						<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['rowNew_1_avatar']; ?>
)"></span>
						<span class="name no-wrap">
							<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['rowNew_1_uid']; ?>
" title="<?php echo $this->_tpl_vars['rowNew_1_nickname']; ?>
">
							<?php echo $this->_tpl_vars['rowNew_1_nickname']; ?>

							</a>
						</span>
					</div>
					<div class="tags">
						<p></p>
					</div>
			   </div>
			</div>
			<div class="flex-item flex-item-all-xs flex-item-order-xs-2 flex-item-order-sm-3 flex-item-order-md-2 flex-item-order-lg-2">
				<div class="visible-md-block visible-lg-block" style="height: 55px"></div>
				<div class="flex flex-column-md flex-column-lg">
					<?php $_from = $this->_tpl_vars['rowNew_2']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowNew_2'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowNew_2']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowNew_2']['iteration']++;
?>
						<div class="flex-item flex-item-half-xs flex-item-order-1">
							<div class="img-box img-box-sm">
								<div class="pic">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
">
										<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
										<span class="play"><i></i></span>
									</a>
									<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
								</div>
								<div class="user">
									<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
									<span class="name no-wrap">
										<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
											<?php echo $this->_tpl_vars['k']['nickname']; ?>

										</a>
									</span>
								</div>
								<div class="tags hidden-md hidden-lg">
									<p></p>
								</div>
							</div>
						</div>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
			<div class="flex-item flex-item-all-xs flex-item-order-xs-3 flex-item-order-sm-4 flex-item-order-md-4 flex-item-order-lg-3">
				<div class="visible-lg-block" style="height: 55px"></div>
				<div class="flex flex-column-lg">
					<?php $_from = $this->_tpl_vars['rowNew_3']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowNew_3'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowNew_3']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowNew_3']['iteration']++;
?>
						<div class="flex-item flex-item-half-xs flex-item-order-1">
							<div class="img-box img-box-sm">
								<div class="pic">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
">
										<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
										<span class="play"><i></i></span>
									</a>
									<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
								</div>
								<div class="user">
									<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
									<span class="name no-wrap">
										<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
											<?php echo $this->_tpl_vars['k']['nickname']; ?>

										</a>
									</span>
								</div>
								<div class="tags hidden-md hidden-lg">
									<p></p>
								</div>
							</div>
						</div>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
			<div class="flex-item flex-item-all-xs flex-item-order-xs-5 flex-item-order-sm-2 flex-item-order-md-3 flex-item-order-lg-4">
				<h2 class="sub-title">排行榜</h2>
				<div class="tops">
					<div class="tabs">
						<a href="javascript:void(0);" id="general" class="active">热文榜</a>|<a href="javascript:void(0);" id="riches">新人榜</a>|<a href="javascript:void(0);" id="new">新评榜</a>
					</div>
					<div class="content">
						<div id="generalContent" style="display:block">
							<?php $_from = $this->_tpl_vars['rowTextHot']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowTextHot'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowTextHot']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowTextHot']['iteration']++;
?>
							<div class="item">
								<div class="index index1"><?php echo $this->_foreach['rowTextHot']['iteration']; ?>
</div>
								<div onClick="location.href='<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['authorId']; ?>
';" class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['img']; ?>
)"></div>
								<div class="user">
									<span class="name no-wrap">
										<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
" title="<?php echo $this->_tpl_vars['k']['title']; ?>
">
										<?php echo $this->_tpl_vars['k']['title']; ?>

										</a>
									</span>
									<span class="fans"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
条评论</span>
								</div>
							</div>
							<?php endforeach; endif; unset($_from); ?>
						</div>
						<div id="richesContent">
							<?php $_from = $this->_tpl_vars['rowUserNew']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowUserNew'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowUserNew']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowUserNew']['iteration']++;
?>
							<div class="item">
								<div class="index index1"><?php echo $this->_foreach['rowUserNew']['iteration']; ?>
</div>
								<div onClick="location.href='<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['uid']; ?>
';" class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></div>
								<div class="user">
									<span class="name no-wrap"><?php echo $this->_tpl_vars['k']['nickname']; ?>
</span>
									<span class="fans"><?php echo $this->_tpl_vars['k']['mail']; ?>
</span>
								</div>
							</div>
							<?php endforeach; endif; unset($_from); ?>
						</div>
						<div id="newContent">
							<?php $_from = $this->_tpl_vars['rowCommentNew']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowCommentNew'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowCommentNew']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowCommentNew']['iteration']++;
?>
							<div class="item">
								<div class="index index1"><?php echo $this->_foreach['rowCommentNew']['iteration']; ?>
</div>
								<div onClick="location.href='<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['authorId']; ?>
';" class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></div>
								<div class="user">
									<span class="name no-wrap">
										<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
" title="<?php echo $this->_tpl_vars['k']['text']; ?>
">
										<?php echo $this->_tpl_vars['k']['text']; ?>

										</a>
									</span>
									<span class="fans"><?php echo $this->_tpl_vars['k']['author']; ?>
</span>
								</div>
							</div>
							<?php endforeach; endif; unset($_from); ?>
						</div>
					</div>
				</div>
			</div>
			<?php $_from = $this->_tpl_vars['rowNew_4']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['rowNew_4'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['rowNew_4']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['rowNew_4']['iteration']++;
?>
			<div class="flex-item flex-item-half-xs flex-item-order-xs-4 flex-item-order-sm-5 flex-item-order-md-5 flex-item-order-lg-5">
				<div class="img-box img-box-sm">
					<div class="pic">
						<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['k']['cid']; ?>
">
							<img src="<?php echo $this->_tpl_vars['k']['img']; ?>
" alt="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
							<p class="views"><span><?php echo $this->_tpl_vars['k']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['k']['commentsNum']; ?>
</span>
							<span class="play"><i></i></span>
						</a>
						<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['k']['title']; ?>
</p></div>
					</div>
					<div class="user">
						<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['k']['avatar']; ?>
)"></span>
						<span class="name no-wrap">
							<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['k']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
								<?php echo $this->_tpl_vars['k']['nickname']; ?>

							</a>
						</span>
					</div>
					<div class="tags">
						<p></p>
					</div>
				</div>
			</div>
			<?php endforeach; endif; unset($_from); ?>
		</div>
		<?php $_from = $this->_tpl_vars['cate']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['cate'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['cate']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k']):
        $this->_foreach['cate']['iteration']++;
?>
		<h2 class="sub-title"><?php echo $this->_tpl_vars['k']['name']; ?>
</h2>
		<div class="flex">
			<?php $_from = $this->_tpl_vars['k']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['catedata'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catedata']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['d']):
        $this->_foreach['catedata']['iteration']++;
?>
			<?php if (($this->_foreach['catedata']['iteration']-1) == 0): ?>
			<div class="flex-item flex-item-all-xs">
				<div class="img-box img-box-lg">
					<div class="pic">
						<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['d']['cid']; ?>
">
							<img src="<?php echo $this->_tpl_vars['d']['img']; ?>
" alt="<?php echo $this->_tpl_vars['d']['nickname']; ?>
">
							<p class="views"><span><?php echo $this->_tpl_vars['d']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['d']['commentsNum']; ?>
</span>
							<span class="play"><i></i></span>
						</a>
						<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['d']['title']; ?>
</p></div>
					</div>
					<div class="user">
						<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['d']['avatar']; ?>
)"></span>
						<span class="name no-wrap">
							<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['d']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
								<?php echo $this->_tpl_vars['d']['nickname']; ?>

							</a>
						</span>
					</div>
					<div class="tags">
						<p></p>
					</div>
				</div>
			</div>
			<?php endif; ?>
			<?php endforeach; endif; unset($_from); ?>
			<div class="flex-item flex-item-all-xs">
				<div class="flex flex-column-sm flex-column-md flex-column-lg">
					<?php $_from = $this->_tpl_vars['k']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['catedata'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catedata']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['d']):
        $this->_foreach['catedata']['iteration']++;
?>
					<?php if (($this->_foreach['catedata']['iteration']-1) > 0 && ($this->_foreach['catedata']['iteration']-1) < 3): ?>
					<div class="flex-item flex-item-half-xs flex-item-order-1">
						<div class="img-box img-box-sm">
							<div class="pic">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['d']['cid']; ?>
">
									<img src="<?php echo $this->_tpl_vars['d']['img']; ?>
" alt="<?php echo $this->_tpl_vars['d']['nickname']; ?>
">
									<p class="views"><span><?php echo $this->_tpl_vars['d']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['d']['commentsNum']; ?>
</span>
									<span class="play"><i></i></span>
								</a>
								<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['d']['title']; ?>
</p></div>
							</div>
							<div class="user">
								<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['d']['avatar']; ?>
)"></span>
								<span class="name no-wrap">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['d']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<?php echo $this->_tpl_vars['d']['nickname']; ?>

									</a>
								</span>
							</div>
							<div class="tags hidden-sm hidden-md hidden-lg">
								<p></p>
							</div>
						</div>
					</div>
					<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
			<div class="flex-item flex-item-all-xs">
				<div class="flex flex-column-sm flex-column-md flex-column-lg">
					<?php $_from = $this->_tpl_vars['k']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['catedata'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catedata']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['d']):
        $this->_foreach['catedata']['iteration']++;
?>
					<?php if (($this->_foreach['catedata']['iteration']-1) > 2 && ($this->_foreach['catedata']['iteration']-1) < 5): ?>
					<div class="flex-item flex-item-half-xs flex-item-order-1">
						<div class="img-box img-box-sm">
							<div class="pic">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['d']['cid']; ?>
">
									<img src="<?php echo $this->_tpl_vars['d']['img']; ?>
" alt="<?php echo $this->_tpl_vars['d']['nickname']; ?>
">
									<p class="views"><span><?php echo $this->_tpl_vars['d']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['d']['commentsNum']; ?>
</span>
									<span class="play"><i></i></span>
								</a>
								<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['d']['title']; ?>
</p></div>
							</div>
							<div class="user">
								<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['d']['avatar']; ?>
)"></span>
								<span class="name no-wrap">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['d']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<?php echo $this->_tpl_vars['d']['nickname']; ?>

									</a>
								</span>
							</div>
							<div class="tags hidden-sm hidden-md hidden-lg">
								<p></p>
							</div>
						</div>
					</div>
					<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
			<div class="flex-item flex-item-all-xs">
				<div class="flex flex-column-md flex-column-lg">
					<?php $_from = $this->_tpl_vars['k']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['catedata'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catedata']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['d']):
        $this->_foreach['catedata']['iteration']++;
?>
					<?php if (($this->_foreach['catedata']['iteration']-1) > 4 && ($this->_foreach['catedata']['iteration']-1) < 7): ?>
					<div class="flex-item flex-item-half-xs flex-item-order-1">
						<div class="img-box img-box-sm">
							<div class="pic">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['d']['cid']; ?>
">
									<img src="<?php echo $this->_tpl_vars['d']['img']; ?>
" alt="<?php echo $this->_tpl_vars['d']['nickname']; ?>
">
									<p class="views"><span><?php echo $this->_tpl_vars['d']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['d']['commentsNum']; ?>
</span>
									<span class="play"><i></i></span>
								</a>
								<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['d']['title']; ?>
</p></div>
							</div>
							<div class="user">
								<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['d']['avatar']; ?>
)"></span>
								<span class="name no-wrap">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['d']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<?php echo $this->_tpl_vars['d']['nickname']; ?>

									</a>
								</span>
							</div>
							<div class="tags hidden-sm hidden-md hidden-lg">
								<p></p>
							</div>
						</div>
					</div>
					<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
			<div class="flex-item flex-item-all-xs">
				<div class="flex flex-column-lg">
					<?php $_from = $this->_tpl_vars['k']['data']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['catedata'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catedata']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['d']):
        $this->_foreach['catedata']['iteration']++;
?>
					<?php if (($this->_foreach['catedata']['iteration']-1) > 6 && ($this->_foreach['catedata']['iteration']-1) < 9): ?>
					<div class="flex-item flex-item-half-xs flex-item-order-1">
						<div class="img-box img-box-sm">
							<div class="pic">
								<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/article.php?cid=<?php echo $this->_tpl_vars['d']['cid']; ?>
">
									<img src="<?php echo $this->_tpl_vars['d']['img']; ?>
" alt="<?php echo $this->_tpl_vars['d']['nickname']; ?>
">
									<p class="views"><span><?php echo $this->_tpl_vars['d']['created']; ?>
</span></p><span class="live"><?php echo $this->_tpl_vars['d']['commentsNum']; ?>
</span>
									<span class="play"><i></i></span>
								</a>
								<div class="intro no-wrap"><p><?php echo $this->_tpl_vars['d']['title']; ?>
</p></div>
							</div>
							<div class="user">
								<span class="head" style="background-image: url(<?php echo $this->_tpl_vars['d']['avatar']; ?>
)"></span>
								<span class="name no-wrap">
									<a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
m/author.php?uid=<?php echo $this->_tpl_vars['d']['uid']; ?>
" title="<?php echo $this->_tpl_vars['k']['nickname']; ?>
">
										<?php echo $this->_tpl_vars['d']['nickname']; ?>

									</a>
								</span>
							</div>
							<div class="tags hidden-sm hidden-md hidden-lg">
								<p></p>
							</div>
						</div>
					</div>
					<?php endif; ?>
					<?php endforeach; endif; unset($_from); ?>
				</div>
			</div>
		</div>
		<?php endforeach; endif; unset($_from); ?>
    </div>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.htm", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>