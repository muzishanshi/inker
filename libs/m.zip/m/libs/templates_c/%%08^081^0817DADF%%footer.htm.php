<?php /* Smarty version 2.6.18, created on 2019-02-15 16:52:51
         compiled from footer.htm */ ?>
<footer>
    <div class="footer_menu row">
		
    </div>
	<p><?php echo $this->_tpl_vars['friends']; ?>
</p>
	<p>分类数&nbsp;<?php echo $this->_tpl_vars['sitedata']['categoriesNum']; ?>
&nbsp;文章数&nbsp;<?php echo $this->_tpl_vars['sitedata']['PublishedPostsNum']; ?>
&nbsp;页面数&nbsp;<?php echo $this->_tpl_vars['sitedata']['PublishedPagesNum']; ?>
&nbsp;评论数&nbsp;<?php echo $this->_tpl_vars['sitedata']['PublishedCommentsNum']; ?>
</p>
    <p><?php echo $this->_tpl_vars['foot_info']; ?>
</p>
    <p>
		Copyright <?php echo $this->_tpl_vars['copydate']; ?>
 <a href="<?php echo $this->_tpl_vars['siteUrl']; ?>
"><?php echo $this->_tpl_vars['title']; ?>
</a> Powered by <a href="http://typecho.org/" title="Typecho" target="_blank" rel="nofollow">Typecho</a> Theme By <a id="rightdetail" href="http://www.tongleer.com" target="_blank" title="同乐儿">Tongleer</a> All rights reserved.
	</p>
    <p class="txt"><?php echo $this->_tpl_vars['foot_beian']; ?>
</p>
</footer>
<div class="qrcode hidden-xs hidden-sm" style="background:url('<?php echo $this->_tpl_vars['qrcode']; ?>
') no-repeat;background-size: 100px 100px;width: 100px;height: 100px;position: fixed;top: 200px;right: 5px;"></div>
<script src="resource/js/bootstrap.min.js"></script>
<script>
$(function() {
	$('.tops>.tabs>a').hover(function() {
		$('.tops>.tabs>a').removeClass('active');
		$('.tops>.content>div').hide();
		var tabId = $(this).attr('id');
		$(this).addClass('active');
		$('#' + tabId + 'Content').show();
	});
	$('a[data-type="download"]').on('click', function(event) {
		var e = navigator.userAgent.toLowerCase();
		event.preventDefault();
		if($(this).attr('id') === 'dashang') {
			if($('.qrcode2').is(':visible')) {
				$('.qrcode2').hide();
			} else {
				$('.qrcode2').show();
			}
			return false;
		}else{
			location.href=$(this).attr('href');
		}
	});
});
</script>
</body>
</html>