<?php
require_once "config/public_function.php";
include_once "../config.inc.php";
include_once "include/function.php";

$db = Typecho_Db::get();
$prefix=$db->getPrefix();
$options=Typecho_Widget::widget('Widget_Options');
$themeOptions=getThemeOptions();

$uid = isset($_GET['uid']) ? addslashes(trim($_GET['uid'])) : 0;

/*favicon*/
$favicon=$themeOptions["head_favicon"];
/*LOGO*/
$logo=$themeOptions["head_logo_img"];
/*分类导航*/
Typecho_Widget::widget('Widget_Metas_Category_List')->to($category);
$i=0;while($category->next()){
	if($category->parent!=0){continue;}
	$cate[$i]["mid"]=$category->mid;
	$cate[$i]["name"]=$category->name;
	$i++;
}

/*用户资料*/
$user=array();
$query= "SELECT * FROM ".$prefix."users WHERE uid=".$uid;
$user = $db->fetchRow($query);
if($user){
	$user["nickname"]=$user["screenName"]!=""?$user["screenName"]:$user["name"];
	$user["created"]=date("Y-m-d",$user["created"]);
	$user["avatar"]=getAuthorAvatar($user["mail"]);
	$smarty->assign("user",$user);
}
/*打赏二维码*/
$smarty->assign("dashang_qrcode",$themeOptions["dashang_qrcode"]);
/*作者文章*/
$page_now = isset($_GET['page_now']) ? addslashes($_GET['page_now']) : 1;
if($page_now<1){
	$page_now=1;
}
$query= "SELECT *,c.cid as ccid,c.created as ccreated FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid WHERE c.type='post' AND c.status='publish' AND u.uid=".$uid;
$resultTotal = $db->fetchAll($query);
$page_rec=12;
$totalrec=count($resultTotal);
$page=ceil($totalrec/$page_rec);

$arr['totalItem'] = $totalrec;
$arr['pageSize'] = $page_rec;
$arr['totalPage'] = $page;

if($page_now>$page){
	$page_now=$page;
}
if($page_now<=1){
	$before_page=1;
	if($page>1){
		$after_page=$page_now+1;
	}else{
		$after_page=1;
	}
}else{
	$before_page=$page_now-1;
	if($page_now<$page){
		$after_page=$page_now+1;
	}else{
		$after_page=$page;
	}
}
$i=($page_now-1)*$page_rec<0?0:($page_now-1)*$page_rec;
$query= "SELECT *,c.cid as ccid,c.created as ccreated FROM ".$prefix."contents AS c INNER JOIN ".$prefix."users AS u ON c.authorId = u.uid WHERE c.type='post' AND c.status='publish' AND u.uid=".$uid." ORDER BY c.created DESC LIMIT ".$i.",".$page_rec;
$rows = $db->fetchAll($query);
$authorArticle=array();
$index=0;foreach($rows as $value){
	$authorArticle[$index]["uid"]=$value["uid"];
	$authorArticle[$index]["cid"]=$value["ccid"];
	$authorArticle[$index]["title"]=$value["title"];
	$authorArticle[$index]["nickname"]=$value["screenName"]!=""?$value["screenName"]:$value["name"];
	$authorArticle[$index]["commentsNum"]=$value["commentsNum"];
	$authorArticle[$index]["created"]=date("Y-m-d",$value["ccreated"]);
	$authorArticle[$index]["img"]=getPostHtmImg($value["text"]);
	$authorArticle[$index]["avatar"]=getAuthorAvatar($value["mail"]);
	$index++;
}
$smarty->assign("uid",$uid);
$smarty->assign("page_now",$page_now);
$smarty->assign("totalrec",$totalrec);
$smarty->assign("before_page",$before_page);
$smarty->assign("after_page",$after_page);
$smarty->assign("page_rec",$page_rec);
$smarty->assign("page",$page);
$smarty->assign("authorArticle",$authorArticle);

/*二维码*/
$qrcode=$themeOptions["head_qrcode"];
/*友情链接*/
$friends=printFriends($themeOptions["foot_friendlink"]);
/*数据统计*/
Typecho_Widget::widget('Widget_Stat')->to($stat);
$sitedata=array("categoriesNum"=>$stat->categoriesNum,"PublishedPostsNum"=>$stat->PublishedPostsNum,"PublishedPagesNum"=>$stat->PublishedPagesNum,"PublishedCommentsNum"=>$stat->PublishedCommentsNum);
/*底部信息*/
$foot_info=$themeOptions["foot_info"];
/*备案信息*/
$foot_beian=$themeOptions["foot_beian"];

$smarty->assign("cate",$cate);

$smarty->assign("favicon",$favicon);
$smarty->assign("logo",$logo);
$smarty->assign("qrcode",$qrcode);
$smarty->assign("copydate",date("Y")."-".date('Y', strtotime("+1 year")));
$smarty->assign("friends",$friends);
$smarty->assign("sitedata",$sitedata);
$smarty->assign("foot_info",$foot_info);
$smarty->assign("foot_beian",$foot_beian);
$smarty->assign("siteUrl",$options->siteUrl);
$smarty->assign("title",$options->title);
$smarty->assign("rowKeywords",$options->keywords);
$smarty->assign("rowDesc",$options->description);
$smarty->display("author.htm");
?>