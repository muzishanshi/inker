<?php
require_once "config/public_function.php";
include_once "../config.inc.php";
include_once "include/function.php";

$db = Typecho_Db::get();
$prefix=$db->getPrefix();
$options=Typecho_Widget::widget('Widget_Options');
$themeOptions=getThemeOptions();
date_default_timezone_set('Asia/Shanghai');

$uid = isset($_GET['uid']) ? addslashes(trim($_GET['uid'])) : 0;
$action = isset($_POST['action']) ? addslashes(trim($_POST['action'])) : "";
if($action=="sendMail"){
	$mail = isset($_POST['mail']) ? addslashes(trim($_POST['mail'])) : "";
	
	if(empty($themeOptions["switch"]) || !in_array('isMailLogin', $themeOptions["switch"])){
		$json=json_encode(array("error_code"=>-2,"message"=>"未开启邮箱登陆"));
		echo $json;
		exit;
	}

	$randCode = '';
	$chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHIJKLMNPRSTUVWXYZ23456789';
	for ( $i = 0; $i < 5; $i++ ){
		$randCode .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
	}
	$_SESSION['smscode'] = strtoupper($randCode);

	$queryTitle= $db->select('value')->from('table.options')->where('name = ?', 'title'); 
	$rowTitle = $db->fetchRow($queryTitle);
	$result=sendMail($mail,'【'.$rowTitle["value"].'】验证码','欢迎使用【'.$rowTitle["value"].'】验证码服务，您的验证码是：'.$_SESSION['smscode']);
	if($result){
		$json=json_encode(array("error_code"=>0,"message"=>"发送成功"));
		echo $json;
	}else{
		$json=json_encode(array("error_code"=>-1,"message"=>"发送失败"));
		echo $json;
	}
	exit;
}else if($action=="ajaxlogin"){
	$mail = isset($_POST['mail']) ? addslashes(trim($_POST['mail'])) : "";
	$pwd = isset($_POST['password']) ? addslashes(trim($_POST['password'])) : "";
	$code = isset($_POST['code']) ? addslashes(trim($_POST['code'])) : "";
	
	if(empty($themeOptions["switch"]) || !in_array('isMailLogin', $themeOptions["switch"])){
		$json=json_encode(array("error_code"=>-2,"message"=>"未开启邮箱登陆"));
		echo $json;
		exit;
	}
	if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$mail)){
		$json=json_encode(array("error_code"=>-4,"message"=>"请输入正确的邮箱"));
		echo $json;
		exit;
	}
	if(strlen($pwd)<6){
		$json=json_encode(array("error_code"=>-5,"message"=>"请输入长度不小于6位的密码"));
		echo $json;
		exit;
	}
	if(empty($themeOptions["switch"])||(!empty($themeOptions["switch"]) && in_array('isShowSmsCode', $themeOptions["switch"]))){
		if(isset($_SESSION['smscode'])&&strcasecmp($_SESSION['smscode'],$code)!=0){
			$json=json_encode(array("error_code"=>-6,"message"=>"邮箱验证码错误"));
			echo $json;
			exit;
		}
	}
	$query= $db->select()->from('table.users')->where('name = ?', $mail)->orWhere('mail = ?', $mail); 
	$user = $db->fetchRow($query);
	if($user){
		$login=Typecho_Widget::widget('Widget_User');
		if(!$login->login($mail,$pwd)){
			$json=json_encode(array("error_code"=>-7,"message"=>"登陆失败，请检查密码是否正确"));
			echo $json;
			exit;
		}
		$json=json_encode(array("error_code"=>0,"message"=>"登陆中"));
		echo $json;
	}else{
		if (!Typecho_Widget::widget('Widget_Options')->allowRegister) {
			$json=json_encode(array("error_code"=>-3,"message"=>"不允许注册"));
			echo $json;
			exit;
		}
		$hasher = new PasswordHash(8, true);
		$dataStruct = array(
			'name'      =>  $mail,
			'mail'      =>  $mail,
			'screenName'=>  $mail,
			'password'  =>  $hasher->HashPassword($pwd),
			'created'   =>  time(),
			'group'     =>  'subscriber'
		);
		$insert = $db->insert('table.users')->rows($dataStruct);
		$insertId = $db->query($insert);
		$json=json_encode(array("error_code"=>0,"message"=>"注册中"));
		echo $json;
	}
	$randCode = '';
	$chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHIJKLMNPRSTUVWXYZ23456789';
	for ( $i = 0; $i < 5; $i++ ){
		$randCode .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
	}
	$_SESSION['smscode'] = strtoupper($randCode);
	exit;
}else if($action=="submitlogin"){
	$mail = isset($_POST['mail']) ? addslashes(trim($_POST['mail'])) : "";
	$pwd = isset($_POST['password']) ? addslashes(trim($_POST['password'])) : "";
	
	$query= $db->select()->from('table.users')->where('name = ?', $mail)->orWhere('mail = ?', $mail); 
	$user = $db->fetchRow($query);
	if($user){
		$login=Typecho_Widget::widget('Widget_User');
		if(!$login->login($mail,$pwd)){
			echo "<script>alert('登陆失败，请检查密码是否正确');location=href='';</script>";exit;
		}
		$authCode = function_exists('openssl_random_pseudo_bytes') ?
			bin2hex(openssl_random_pseudo_bytes(16)) : sha1(Typecho_Common::randString(20));
		$user['authCode'] = $authCode;

		Typecho_Cookie::set('__typecho_uid', $user['uid'], 0);
		Typecho_Cookie::set('__typecho_authCode', Typecho_Common::hash($authCode), 0);

		$db->query($db
		->update('table.users')
		->expression('logged', 'activated')
		->rows(array('authCode' => $authCode))
		->where('uid = ?', $user['uid']));
		
		echo "<script>location=href='".$options->siteUrl."m';</script>";
	}else{
		if (!Typecho_Widget::widget('Widget_Options')->allowRegister) {
			echo "<script>alert('不允许注册');location=href='';</script>";exit;
		}
		$hasher = new PasswordHash(8, true);
		$dataStruct = array(
			'name'      =>  $mail,
			'mail'      =>  $mail,
			'screenName'=>  $mail,
			'password'  =>  $hasher->HashPassword($pwd),
			'created'   =>  time(),
			'group'     =>  'subscriber'
		);
		$insert = $db->insert('table.users')->rows($dataStruct);
		$insertId = $db->query($insert);
		
		$login=Typecho_Widget::widget('Widget_User')->login($mail,$pwd);
		
		Typecho_Cookie::delete('__typecho_first_run');
		
		$randCode = '';
		$chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHIJKLMNPRSTUVWXYZ23456789';
		for ( $i = 0; $i < 5; $i++ ){
			$randCode .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		$_SESSION['smscode'] = strtoupper($randCode);
		
		echo "<script>location=href='".$options->siteUrl."m';</script>";exit;
	}
}

/*favicon*/
$favicon=$themeOptions["head_favicon"];
/*LOGO*/
$logo=$themeOptions["head_logo_img"];
/*分类导航*/
Typecho_Widget::widget('Widget_Metas_Category_List')->to($category);
$i=0;while($category->next()){
	if($category->parent!=0){continue;}
	$cate[$i]["mid"]=$category->mid;
	$cate[$i]["name"]=$category->name;
	$i++;
}

/*判断是否开启短信验证登陆*/
$isShowSmsCode=empty($themeOptions["switch"])||(!empty($themeOptions["switch"]) && in_array('isShowSmsCode', $themeOptions["switch"]));
$loginAction=str_replace("m/index.php/","index.php/action/login",@$options->loginAction);
$smarty->assign("loginAction",$loginAction);
$smarty->assign("isShowSmsCode",$isShowSmsCode);

/*二维码*/
$qrcode=$themeOptions["head_qrcode"];
/*友情链接*/
$friends=printFriends($themeOptions["foot_friendlink"]);
/*数据统计*/
Typecho_Widget::widget('Widget_Stat')->to($stat);
$sitedata=array("categoriesNum"=>$stat->categoriesNum,"PublishedPostsNum"=>$stat->PublishedPostsNum,"PublishedPagesNum"=>$stat->PublishedPagesNum,"PublishedCommentsNum"=>$stat->PublishedCommentsNum);
/*底部信息*/
$foot_info=$themeOptions["foot_info"];
/*备案信息*/
$foot_beian=$themeOptions["foot_beian"];

$smarty->assign("cate",$cate);

$smarty->assign("favicon",$favicon);
$smarty->assign("logo",$logo);
$smarty->assign("qrcode",$qrcode);
$smarty->assign("copydate",date("Y")."-".date('Y', strtotime("+1 year")));
$smarty->assign("friends",$friends);
$smarty->assign("sitedata",$sitedata);
$smarty->assign("foot_info",$foot_info);
$smarty->assign("foot_beian",$foot_beian);
$smarty->assign("siteUrl",$options->siteUrl);
$smarty->assign("title",$options->title);
$smarty->assign("rowKeywords",$options->keywords);
$smarty->assign("rowDesc",$options->description);
$smarty->display("login.htm");
?>